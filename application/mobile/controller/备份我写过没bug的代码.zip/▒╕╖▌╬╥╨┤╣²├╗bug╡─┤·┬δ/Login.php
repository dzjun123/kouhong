<?php
namespace app\mobile\controller;

use app\common\model\RougeSystem;
use app\common\model\RougeUser;
use think\Request;
use think\Session;

class Login extends Base
{
    //推荐别人进来的地址进入这里
    public function index(Request $request)
    {
//        dump($request->isAjax());exit; //通过地址访问的false
        if ($request->isAjax()){
            $model = new RougeSystem();
            $param = $request->post(); 
//            $init = Session::get();
            $map['uniacid'] = $param['uniacid'];
            $list = $model->where($map)->field('loading_url')->find(); 
            $list['loading_url']=str_replace('\\', '/', $list['loading_url']);  //处理斜杠的问题
            if ($list){
                $rarr['code'] = 0;
                $rarr['message'] = 'success';
                $rarr['data'] = $list;
            }else{
                $rarr['code'] = 9001;
                $rarr['message'] = 'error';
                $rarr['data'] = $list;
            }
            return json($rarr);
        }else { 
            $url = $request->url(true);
            $param = $request->param();
            if (!isset($param['platid'])) {
                $this->error('请刷新页面后重试');
                exit();
            }
            $plat = $param['platid']; //商户编号
            
            //测试
//            $openid= "oSvf_0lw9jIH4-C2W6YOQBiHoe7g"; //openid
//            $user_id=1; //user_id
//            $uniacid= 1; //uniacid
            
            $openid= Session::get($plat."_openid"); //openid
            $user_id= Session::get("user_id"); //user_id
            $uniacid= Session::get("uniacid"); //uniacid
            
            //判断用户openid,id,uniacid是否存在
            if(empty($openid)&&empty($user_id)&&empty($uniacid)){
                $this->init_login($url); 
                  
            }else{
                //不为空的时候  
                Session::set($plat."_openid",$openid);
                Session::set('user_id', $user_id);
                Session::set('uniacid',$uniacid);
                
                $system = new RougeSystem();
                $map['uniacid'] = $uniacid;
                $sysinfo = $system->where($map)->field('title,uniacid')->find();
                $this->assign('sysinfo', $sysinfo);
                //END
                $jssdkconfig = $this->getjssdk();      //
                $jssdksharedata = $this->getsharedata($sysinfo);    //
                $jssdkconfig = json_encode($jssdkconfig);
                $this->assign('jssdkconfig', $jssdkconfig);
                $this->assign('jssdksharedata', $jssdksharedata);
                //获取信息授权END 
              
            } 
                $data=Session::get("user_info");
                $model = new RougeUser(); 
                $model->allowField(true)->save($data); 
               
                Session::set('user_id', $model->id);
                
                $user['openid'] = '';
                $user = $this->getuserinfo();
                if (!$user){
                    $user['platid'] = $request->param('platid');
                    $user['uniacid'] = $user['platid'] ;
                }
                $this->assign('user',$user);
                //END 
                if (isset($param['outer'])){
                    $info['outer'] = $param['outer'];
                }else{
                    $info['outer'] = '';
                }
                $this->assign('info',$info); 
               
                return $this->fetch(); 
        }
    }

    //获取code
    public function getuserauth(Request $request){

    }

    public function loguot(){
        Session::clear();
    }
}
