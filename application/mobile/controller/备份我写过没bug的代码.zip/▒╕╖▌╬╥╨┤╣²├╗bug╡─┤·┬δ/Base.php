<?php

namespace app\mobile\controller;

use app\common\model\RougeSystem;
use app\common\model\RougeSystemWx;
use app\common\model\RougeUser;
use think\Controller;
use think\Session;
use Wechat\WechatApi;

class Base extends Controller
{
     public function init_login($url = '') {
         $param = request()->param();
         error_log(time().":login:".json_encode($param));
        if (!isset($param['platid'])) {
            $this->error('请刷新页面后重试');
            exit();
        } 
        $plat = $param['platid']; 
        $option = $this->option($plat);
        $WxObj = new WechatApi($option);
        $model = new RougeUser();
         if ( empty($param['code'])&&empty($param['state'])) { 
              $callback = $url;
              $url = $WxObj->getOauthRedirect($callback, "STATE",$scope='snsapi_userinfo');
              error_log(time().":login_code:".$url);
              header("Location:$url");
              exit();
         }else if (intval($param["state"]) == "STATE") { 
             if(!Session::get($plat."_openid")){ //存在就不再重复请求接口
                    $userinfo = $WxObj->getOauthAccessToken();
                    error_log(time().":state:".json_encode($userinfo));
                    $openid=$userinfo['openid'];
                    Session::set($plat."_openid",$openid);
                    Session::set('uniacid', $plat);
                    $users = $WxObj->getOauthUserinfo($userinfo['access_token'], $openid);

                    if ($users) { 
                       if (isset($param['outer'])) {
                              $data['top_openid'] = $param['outer'];
                              $data['type'] = 1;//别人推荐的
                       }
                       $data['openid'] = $users['openid'];
                       $data['nickname'] = $users['nickname'];
                       $data['sex'] = $users['sex'];
                       $data['header_url'] = $users['headimgurl'];
                       $data['wx_info'] = json_encode($users, JSON_UNESCAPED_UNICODE);
                       $data['uniacid'] = $plat; 
                       $data['create_time'] = time();
                       error_log('add_beford');
                       //$model->allowField(true)->save($data);
                       Session::set("user_info",$data);
                       error_log('add_edd');
                       //$users['id']=$model->id;
                      //$users['uniacid']=$plat;

                       //$users = $model->where('openid', $openid)->find();

                       //Session::set('user_id', $users['id']);
//                       var_dump(111222);exit;
                       $system = new RougeSystem();
                       $map['uniacid'] = $plat;
                       $sysinfo = $system->where($map)->field('title,uniacid')->find();
                       $this->assign('sysinfo', $sysinfo);
                       //END
                       $jssdkconfig = $this->getjssdk();      //
                       $jssdksharedata = $this->getsharedata($sysinfo);    //
                       $jssdkconfig = json_encode($jssdkconfig);
                       $this->assign('jssdkconfig', $jssdkconfig);
                       $this->assign('jssdksharedata', $jssdksharedata);
                       //获取信息授权END
                       

                }else{
                    die("系统错误，请稍后再试!");
                }
            }
             
         } else {
            die("用户取消授权!");
        }    
         
    }
    
    
    public function init($url = '') { 
         $param = request()->param();
         
         error_log(time()."::init_url::". $url);
         error_log(time()."::init_param::".  json_encode($param));
         if (!isset($param['platid'])) {
            $this->error('请刷新页面后重试');
            exit();
        }
        $plat = $param['platid']; 
//         $plat=Session::get('uniacid');
//        if (!isset($plat)) {
//            $this->error('请刷新页面后重试222');
//            exit();
//        }
//        $plat =Session::get('uniacid' );   
//        Session::set('uniacid', $plat);
        $system = new RougeSystem();
        $map['uniacid'] = $plat;
        $sysinfo = $system->where($map)->field('title,uniacid')->find();
        $this->assign('sysinfo', $sysinfo);
        //END
        $jssdkconfig = $this->getjssdk();      //
        $jssdksharedata = $this->getsharedata($sysinfo);    //
        $jssdkconfig = json_encode($jssdkconfig);
        $this->assign('jssdkconfig', $jssdkconfig);
        $this->assign('jssdksharedata', $jssdksharedata); 
    }
    
    
    public function init_bk($url = '')
    {
        $param = request()->param();
        if (!isset($param['platid'])) {
            $this->error('请刷新页面后重试');
            exit();
        }
        $plat = $param['platid'];
//Session::set($plat.'_openid','oSvf_0lw9jIH4-C2W6YOQBiHoe7g');
        $openid = Session::get($plat . "_openid");
        $option = $this->option($plat);
        $WxObj = new WechatApi($option);
        $model = new RougeUser();
        
        if (!$openid) {
            $userinfo = $WxObj->getOauthAccessToken(); 
            //获取授权为空时向微信发送请求 
            if (!$userinfo) {
//                var_dump('2'.json_encode($userinfo)); 
                $request = request();
                if (!$url) {
                    $url = $request->url(true);
                }
                $callback = $url;
//                $url = $WxObj->getOauthRedirect($callback, '', 'snsapi_userinfo');
                $url = $WxObj->getOauthRedirect($callback, "1");
                header("Location:$url");
                exit();
            } else {
//                var_dump('3'.json_encode($userinfo));exit;
                $openid=$userinfo['openid']; 
                 Session::set($plat."_openid",$openid);
                $user = $model->where('openid', $openid)->find();
                if (!$use) { //用户信息为空
                    $users = $WxObj->getOauthUserinfo($userinfo['access_token'], $openid);
                    if (isset($param['outer'])) {
                        $data['top_openid'] = $param['outer'];
                        $data['type'] = 1;
                    }
                    
                    $data['openid'] = $users['openid'];
                    $data['nickname'] = $users['nickname'];
                    $data['sex'] = $users['sex'];
                    $data['header_url'] = $users['headimgurl'];
                    $data['wx_info'] = json_encode($users, JSON_UNESCAPED_UNICODE);
                    $data['uniacid'] = $plat;

                    $data['create_time'] = time();
                    
                    $model->allowField(true)->save($data);
                     
                    $users['id']=$model->id;
                    $users['uniacid']=$plat;
                }else{
                    $users['id']=$user['id'];
                    $users['uniacid']=$user['uniacid'];
                }
                $users = $model->where('openid', $openid)->find();
                Session::set('user_id', $users['id']);
                Session::set('uniacid', $users['uniacid']);
                $system = new RougeSystem();
                $map['uniacid'] = $users['uniacid'];
                $sysinfo = $system->where($map)->field('title,uniacid')->find();
                $this->assign('sysinfo', $sysinfo);
                //END
                $jssdkconfig = $this->getjssdk();      //
                $jssdksharedata = $this->getsharedata($sysinfo);    //
                $jssdkconfig = json_encode($jssdkconfig);
                $this->assign('jssdkconfig', $jssdkconfig);
                $this->assign('jssdksharedata', $jssdksharedata);
                //获取信息授权END
                //var_dump(111);exit;
            }
        }else{
            //这里没问题的代码
            $users = $model->where('openid', $openid)->find();
            Session::set('user_id', $users['id']);
            Session::set('uniacid', $users['uniacid']);
            $system = new RougeSystem();
            $map['uniacid'] = $users['uniacid'];
            $sysinfo = $system->where($map)->field('title,uniacid')->find();
            $this->assign('sysinfo', $sysinfo);
            //END
            $jssdkconfig = $this->getjssdk();      //
            $jssdksharedata = $this->getsharedata($sysinfo);    //
            $jssdkconfig = json_encode($jssdkconfig);
            $this->assign('jssdkconfig', $jssdkconfig);
            $this->assign('jssdksharedata', $jssdksharedata);
        }
    }

    public function getuserinfo()
    {
        $RougeUser = new RougeUser();
        $se = Session::get();
        $map['uniacid'] = $se['uniacid'];
        $map['id'] = $se['user_id'];
        $user = $RougeUser->where($map)->find();
        return $user;
    }

    public function getopacid()
    {

    }


    public function getorderno()
    {
        $order = date('YmdHis') . rand(10000, 99999);
        return $order;
    }

    //获取订单
    public function getorder2($sh = 666)
    {
        $order = "H" . $sh . "-" . date('YmdHis') . rand(10000, 99999);
        return $order;
    }


    public function getjssdk()
    {
        $url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
        $options = $this->options();
        //分享
        $weObj = new WechatApi($options);
        $jssdk = $weObj->getJsSign($url);
        $wxJsSdk = [
            'debug' => false,
            'appId' => $jssdk['appId'],
            'timestamp' => $jssdk['timestamp'],
            'nonceStr' => $jssdk['nonceStr'],
            'signature' => $jssdk['signature'],
            'jsApiList' => [
                'openAddress', 'onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone', 'startRecord', 'stopRecord', 'onVoiceRecordEnd', 'playVoice',
                'pauseVoice' . 'stopVoice', 'onVoicePlayEnd', 'uploadVoice', 'downloadVoice', 'chooseImage', 'previewImage', 'uploadImage', 'downloadImage', 'translateVoice', 'getNetworkType', 'openLocation',
                'getLocation', 'hideOptionMenu', 'showOptionMenu', 'hideMenuItems', 'showMenuItems', 'hideAllNonBaseMenuItem', 'showAllNonBaseMenuItem', 'closeWindow', 'scanQRCode', 'chooseWXPay', 'openProductSpecificView'
            ]
        ];
        return $wxJsSdk;
    }

    public function getsharedata($param)
    {
        $data = [
            'imgUrl'=>'http://kouhong.easyke.wang/uploads/index/20181204/e81d88c9f0c0197495682207ea561dcb.jpg',
            'title' => $param['title'],
            'title_line'=>'圣罗兰/迪奥/纪梵希/TOM FORM/MAC官网口红闯关赢回家',
            'desc' => "圣罗兰/迪奥/纪梵希/TOM FORD/MAC官网口红送到家",//连续闯三关专柜/官网口红送到家",
            'link' => request()->domain() . '/mobile.php/login/index/platid/' . $param['uniacid']

        ];
        return $data;
    }

    //微信API参数  根据card_id获取
    /*
     * $card_id
     */
    public function option($plat)
    {
        //  Session::set('openid', null);
        $model = new RougeSystemWx();
        $mab['uniacid'] = $plat;
        $users = $model->where($mab)->field('appid,appsecret,token,encodingaeskey')->find();
        $options = array(
            'appid' => $users['appid'], // 填写高级调用功能的app id
            'appsecret' => $users['appsecret'], // 填写高级调用功能的密钥
            'token' => $users['token'], // 填写你设定的key
            'encodingaeskey' => $users['encodingaeskey'], // 填写加密用的EncodingAESKey
        );
        return $options;
    }

    //微信API参数  根据card_id获取
    /*
     * $card_id
     */
    public function options()
    {
        //  Session::set('openid', null);
        $model = new RougeSystemWx();
        $mab['uniacid'] = Session::get('uniacid');
        $users = $model->where($mab)->field('appid,appsecret,token,encodingaeskey,mch_id,partnerkey')->find();
        $options = array(
            'appid' => $users['appid'], // 填写高级调用功能的app id
            'mch_id' => $users['mch_id'], // 填写高级调用功能的app id
            'partnerkey' => $users['partnerkey'], // 填写高级调用功能的app id
            'appsecret' => $users['appsecret'], // 填写高级调用功能的密钥
            'token' => $users['token'], // 填写你设定的key
            'encodingaeskey' => $users['encodingaeskey'], // 填写加密用的EncodingAESKey
        );
        return $options;
    }
}
